#include <cstdio>
#include <algorithm>

typedef std::pair<int, int> Pair;
int n, m, sum[30][100001], a[30][100001];
Pair b[100001];
inline bool operator<(const Pair& lhs, const Pair& rhs)
{ return lhs.first < rhs.first || (lhs.first == rhs.first && lhs.second < rhs.second); }
void Build(const int deep, const int lef, const int rig)
{
  if (lef == rig)
    return;
  const int mid((lef+rig)>>1);
  int CountLeft = 0, l = lef-1, r = mid;
  for (int i = lef; i <= rig; ++i)
    if (l <= mid && a[deep-1][i] <= b[mid].first)
    {
      a[deep][++l] = a[deep-1][i];
      sum[deep][i] = ++CountLeft;
    }
    else
    {
      a[deep][++r] = a[deep-1][i];
      sum[deep][i] = CountLeft;
    }
  Build(deep+1, lef, mid);
  Build(deep+1, mid+1, rig);
}
int Query(const int deep, const int st, const int ed, const int lef, const int rig, const int k)
{
  if (lef == rig)
    return a[deep-1][lef];
  const int mid = (st+ed)>>1;
  const int nl = lef == st ? 0 : sum[deep][lef-1];
  const int nr = sum[deep][rig];
  if (nr-nl >= k)
    return Query(deep+1, st, mid, nl+st, st+nr-1, k);
  else
    return Query(deep+1, mid+1, ed, mid+1+lef-st-nl, mid+1+rig-st-nr, k-nr+nl);
}
int main()
{
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= n; ++i)
  {
    scanf("%d", &b[i].first);
    a[0][i] = b[i].first;
    b[i].second = i;
  }
  std::sort(b+1, b+1+n);
  Build(1, 1, n);
  for (int lef, rig, k; m; --m)
  {
    scanf("%d%d%d", &lef, &rig, &k);
    printf("%d\n", Query(1, 1, n, lef, rig, k));
  }
}