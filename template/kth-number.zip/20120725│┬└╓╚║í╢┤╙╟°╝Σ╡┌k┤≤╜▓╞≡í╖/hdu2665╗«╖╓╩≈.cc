#include <cstdio>
#include <algorithm>

const int MAXN = 100000;
int TestData, n, m, a[MAXN+1], seg[30][MAXN+1], sum[30][MAXN+1];
void Build(const int deep, const int lef, const int rig)
{
  if (lef == rig)
    return;
  const int mid = (lef+rig)/2;
  int lsame = mid-lef+1;
  for (int i = lef; i <= rig; ++i)
    lsame -= seg[deep-1][i] < a[mid];
  for (int i = lef, p = lef, q = mid+1; i <= rig; ++i)
  {
    sum[deep-1][i] = i == lef ? 0 : sum[deep-1][i-1];
    if (seg[deep-1][i] < a[mid])
    {
      seg[deep][p++] = seg[deep-1][i];
      ++sum[deep-1][i];
    }
    else if (seg[deep-1][i] > a[mid])
      seg[deep][q++] = seg[deep-1][i];
    else
      if (--lsame >= 0)
      {
        seg[deep][p++] = seg[deep-1][i];
        ++sum[deep-1][i];
      }
      else
        seg[deep][q++] = seg[deep-1][i];
  }
  Build(deep+1, lef, mid);
  Build(deep+1, mid+1, rig);
}
int Query(const int deep, const int st, const int ed, const int lef, const int rig, const int k)
{
  if (lef == rig)
    return seg[deep][lef];
  const int cl = lef == st ? 0 : sum[deep][st-1];
  const int cr = sum[deep][ed];
  const int mid = (lef+rig)/2;
  if (cr-cl >= k)
    return Query(deep+1,           lef+cl,           lef+cr-1,   lef, mid, k);
  return Query(deep+1, mid+(st-lef+1)-cl, mid+(ed-lef+1)-cr, mid+1, rig, k-(cr-cl));
}
void Solve()
{
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= n; ++i)
  {
    scanf("%d", a+i);
    seg[0][i] = a[i];
  }
  std::sort(a+1, a+1+n);
  Build(1, 1, n);
  for (int st, ed, k; m--; )
  {
    scanf("%d%d%d", &st, &ed, &k);
    printf("%d\n", Query(0, st, ed, 1, n, k));
  }
}
int main()
{
  scanf("%d", &TestData);
  while (TestData--)
  {
    Solve();
  }
}
