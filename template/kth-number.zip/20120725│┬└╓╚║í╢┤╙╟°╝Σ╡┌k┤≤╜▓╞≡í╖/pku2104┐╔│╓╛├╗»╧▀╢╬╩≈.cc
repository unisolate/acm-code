#include <cstdio>
#include <vector>
#include <algorithm>

const int MAXN = 100000, MAXM = 5000;
struct SegmentNode
{
  int Value;
  SegmentNode *Lef, *Rig;
  SegmentNode(const int value = 0, SegmentNode * const lef = NULL, SegmentNode * const rig = NULL): Value(value), Lef(lef), Rig(rig) { }
} _s[MAXN*4+MAXN*17], *root[MAXN+1];
int NodeSize, n, m, a[MAXN+1], b[MAXN+1];
int st, ed, x;
SegmentNode* Build(const int lef, const int rig)
{
  if (lef == rig)
  {
    _s[NodeSize] = SegmentNode();
    return _s+(NodeSize++);
  }
  const int mid = (lef+rig)/2;
  SegmentNode *node = _s+(NodeSize++);
  node->Value = 0;
  node->Lef = Build(lef, mid);
  node->Rig = Build(mid+1, rig);
  return node;
}
SegmentNode* new_archive(SegmentNode* const pre, const int lef, const int rig)
{
  SegmentNode *node = _s+(NodeSize++);
  node->Value = pre->Value + x;
  node->Lef = pre->Lef;
  node->Rig = pre->Rig;
  if (lef == rig) return node;
  const int mid = (lef+rig)/2;
  if (st <= mid) node->Lef = new_archive(pre->Lef, lef, mid);
  if (mid+1 <= ed) node->Rig = new_archive(pre->Rig, mid+1, rig);
  return node;
}
int query(SegmentNode* const p1, SegmentNode* const p2, const int lef, const int rig, const int k)
{
  if (lef == rig) return lef;
  const int mid = (lef+rig)/2;
  const int count = p2->Lef->Value - p1->Lef->Value;
  if (k <= count) return query(p1->Lef, p2->Lef, lef, mid, k);
  return query(p1->Rig, p2->Rig, mid+1, rig, k-count);
}
inline SegmentNode* NewArchive(SegmentNode* const latest, const int index, const int delta)
{
  st = ed = index, x = delta;
  return new_archive(latest, 1, n);
}
inline int Query(const int lef, const int rig, const int k)
{
  st = lef, ed = rig;
  return query(root[lef-1], root[rig], 1, n, k);
}
int main()
{
  std::vector<int> v;
  scanf("%d%d", &n, &m);
  for (int i = 1; i <= n; ++i)
  {
    scanf("%d", a+i);
    v.push_back(a[i]);
  }
  std::sort(v.begin(), v.end());
  v.resize(n = std::unique(v.begin(), v.end()) - v.begin());

  root[0] = Build(1, n);
  for (int i = 1; i <= n; ++i)
  {
    b[i] = std::lower_bound(v.begin(), v.end(), a[i])-v.begin()+1;
    root[i] = NewArchive(root[i-1], b[i], 1);
  }
  for (int st, ed, k; m--; )
  {
    scanf("%d%d%d", &st, &ed, &k);
    printf("%d\n", v[Query(st, ed, k)-1]);
  }
}